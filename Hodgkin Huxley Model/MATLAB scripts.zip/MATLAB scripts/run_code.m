%{
amp1 = 6;
width1 = 1;

for i = 1:11
    hhmplot(0, 50, 1);
    amp1 = 6 + 0.1*i;
    
end

amp1 = 6.9;
width1 = 1;

for i = 1: 10
    hhmplot(0, 50, 1);
    amp1 = 6.9 + 0.01*i;
end

amp1 = 6.83;
width1 = 1;
[qna, qk , ql] = hhsplot(0, 50)

sum_Jk = qna + qk + ql

amp1 = 7.05;
width1 = 1;
[qna, qk , ql] = hhsplot(0, 50)

sum_Jk = qna + qk + ql

amp1 = 27.4;  
width1 = 0.5;  
delay2 = 6;  
amp2 = 143;  
width2 = 0.5;  

for j =  1:6
    hhmplot(0, 30, 1);
    amp2 = amp2 + 0.1;
end

delays = [6, 8, 10, 12, 14, 16, 18, 20, 25];
I2ths = [143.6, 69.6, 40.5, 25.3, 16.9, 12.7, 11.3, 11.6, 13.7];
ratios = I2ths / 27.4;

t = linspace(4, 25, 1000);
f = spline(delays, ratios, t);

plot(t, f, 'LineWidth', 2);
yline(1, 'r--', 'LineWidth', 1); 
grid on;
xlabel('Delay (ms)');
ylabel('I_2/I_1 Ratio');
title('I_2/I_1 Ratio vs Delay');


amp1 = 5;
width1 = 80;
delay2 = 0;
amp2 = 0;
width2 = 0;

hhmplot(0, 100, 0);

amplitudes = [5 10 20 30 50 70 100];
frequencies = [1 6 7 8 10 11 12];

x = linspace(min(amplitudes), max(amplitudes), 1000);
f = spline(amplitudes, frequencies, x); % Spline interpolation

figure;
plot(x, f, 'b-', 'LineWidth', 2); % Interpolated curve
hold on;
plot(amplitudes, frequencies, 'ro', 'MarkerSize', 8, 'LineWidth', 2); % Data points
xlabel('Amplitude (\muA/cm^2)');
ylabel('Frequency (Number of Action Potentials Triggered)');
title('Amplitude vs Frequency of Triggered Action Potentials');
ylim([0 15]);
grid on;

%}


vclamp = 0;
amp1 = 20;
width1 = 0.5;

temp = [0, 5, 10, 15, 20, 24, 25, 26, 30];

for i = 1:length(temp)
    tempc = temp(i);
    hhmplot(0, 30, 1);
    legend('show');
end








